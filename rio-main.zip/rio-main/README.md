# ☕ RIO Coffee — Web Sitesi + Admin Paneli

Karakol'da faaliyet gösteren RIO Coffee için özel geliştirilmiş kafe web sitesi.
Modern altın/dark tasarım, çift dilli (Rusça / Kırgızca) ve tam yönetilebilir admin paneli.

## 🚀 Özellikler

- **Ana site** — hero, menü, galeri, video, hakkımızda, yorumlar, rezervasyon, iletişim
- **Çift dil** — RU / KG anlık geçiş
- **Admin paneli** — `/admin` adresinde, şifre korumalı
- **Yönetilebilen her şey:**
  - ☕ Ürünler (ekle / düzenle / sil)
  - 🎬 Videolar (YouTube embed)
  - 🖼 Galeri fotoğrafları
  - 📢 Duyuru çubuğu
  - 🪑 Rezervasyon talepleri
  - ⭐ Müşteri yorumları
  - 🌐 Ana ekran metni, çalışma saatleri, sosyal medya, kategori adları, adres & telefon
  - ⚙️ Admin şifresi

## 🛠 Teknoloji

- Saf Node.js (harici bağımlılık yok)
- JSON dosya tabanlı depolama (`data.json`)
- Şifre hash'leri `config.json` içinde (SHA-256)

## 🖥 Yerel Çalıştırma

```bash
cd rio-cafe
node server.js
```

Site: `http://localhost:8000`
Admin paneli: `http://localhost:8000/admin`
Varsayılan giriş: `admin` / `rio123`  ⚠️ **Yayınlamadan önce değiştirin!**

## 🌍 Yayınlama (Deploy)

Bu proje bir **sunucu** çalıştırdığı için statik hosting (ör. GitHub Pages) ile admin paneli
ÇALIŞMAZ. Aşağıdaki seçeneklerden birini kullanın:

### Seçenek A — Railway (kolay, önerilen)
1. Kodunuzu GitHub'a yükleyin
2. [railway.app](https://railway.app) → New Project → Deploy from GitHub repo
3. Start command: `node server.js` (package.json otomatik algılanır)
4. Railway size otomatik bir URL verir (örn. `rio-production.up.railway.app`)
5. Özel domain: Settings → Networking → Generate Domain / Custom Domain

### Seçenek B — Render
1. [render.com](https://render.com) → New → Web Service → connect GitHub
2. Build command boş, Start command: `node server.js`
3. Node sürümü 16+ seçin
4. Render size `https://rio.onrender.com` benzeri bir URL verir

### Seçenek C — Kendi VPS / Sunucu
```bash
# Ubuntu/Debian örneği
sudo apt update && sudo apt install -y nodejs npm git
git clone https://github.com/KULLANICIADI/rio-coffee.git
cd rio-coffee
node server.js &
```
Kalıcı çalışması için `pm2` kullanın:
```bash
npm install -g pm2
pm2 start server.js --name rio
pm2 save && pm2 startup
```

## 🌐 Alan Adı (Domain) Alma

1. Bir alan adı satın alın — örnekler:
   - [Namecheap](https://namecheap.com), [GoDaddy](https://godaddy.com), [Cloudflare](https://cloudflare.com) (Cloudflare'da maliyetine satış var)
   - Örn. `riocoffee.kg`, `riocoffee.xyz`, `riocoffee.com`
2. Hosting sağlayıcınızın (Railway/Render) panelinden **Custom Domain** bölümünü açın
3. Size verilen DNS kaydını (genelde `CNAME` veya `A`) alan adı sağlayıcınızın DNS paneline ekleyin
4. DNS yayılması 5 dk – 24 saat sürebilir
5. HTTPS sertifikası otomatik verilir (Railway/Render ücretsiz SSL sağlar)

## ⚠️ Yayınlama Öncesi Kontrol Listesi

- [ ] Admin şifresini değiştirin (`/admin` → Настройки)
- [ ] Gerçek telefon numarasını ve adresi girin
- [ ] Instagram/WhatsApp/Telegram linklerinizi ekleyin
- [ ] Kategorileri, ürünleri ve fiyatları güncelleyin
- [ ] Kendi logonuzu / fotoğraflarınızı ekleyin

## 📁 Proje Yapısı

```
rio-cafe/
├── server.js        # Node.js sunucusu + API
├── index.html       # Ana site
├── admin.html       # Admin paneli
├── data.json        # Veriler (ürünler, yorumlar, rezervasyonlar...)
├── config.json      # Şifre hash'i (oluşturulur, repoya yüklenmez)
├── img/             # Görseller
└── package.json
```
